# Building RuneSchema 0.6.1 Experimental

## Included material

```text
Source/
├── CMakeLists.txt
├── README.md
├── include/
└── src/
```

These are the complete project-owned source files needed to configure and compile this RuneSchema variant. Third-party dependencies are intentionally not copied into the bundle; CMake downloads the pinned dependencies declared in `CMakeLists.txt`.

## Requirements

- Windows 10 or later.
- Visual Studio 2022 or later with the **Desktop development with C++** workload.
- A Windows SDK and MSVC x64 compiler.
- CMake 3.22 or later.
- Git, for CMake `FetchContent` dependencies.
- A current stable Rust toolchain, required by the pinned UE4SS dependency.
- Internet access during the first configuration so CMake can retrieve UE4SS, nlohmann/json, SafetyHook, Glaze, efsw, and Zydis.

## Configure and compile

Open a Developer PowerShell terminal in the included `Source` directory and run:

```powershell
cmake -S . -B build -A x64
cmake --build build --config Game__Shipping__Win64 --target RuneSchema
```

The compiled DLL will be written to:

```text
Source/build/Game__Shipping__Win64/RuneSchema.dll
```

For installation, rename or copy it as:

```text
RuneSchema/dlls/main.dll
```

## Ready-built package

The sibling `Packaged Build` directory contains a ready-to-install ZIP. It already has the required structure:

```text
RuneSchema/
├── enabled.txt
├── dlls/main.dll
├── config/config.json
└── mods/mods.txt
```

The runtime directory is `config`, singular. Renaming it to `configs` will prevent RuneSchema from finding its configuration.

## Verified build

- Runtime version: `0.6.1 Experimental`
- Configuration: `Game__Shipping__Win64`
- DLL SHA-256: `7EA7A84662CAD4B0A0D8039265B65711AF3B0441FAD357EE731F7655DF1FE7FC`
